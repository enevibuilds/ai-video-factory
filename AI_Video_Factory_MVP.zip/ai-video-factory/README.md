# AI Video Factory — MVP

A mobile-friendly AI video production package generator.

## What it does
Topic → Script → Scenes → Image prompts → Video prompts → Voiceover → SEO.

## Free MVP deployment
This project is designed for Cloudflare Pages + Pages Functions.

1. Create a GitHub repository.
2. Upload all files in this folder.
3. In Cloudflare Pages, import the repository.
4. Set the build command to `exit 0`.
5. Set the build output directory to `/`.
6. Add an environment variable/secret named `GEMINI_API_KEY`.
7. Deploy.

Keep the Gemini key server-side. Never put it in `app.js`.

## Local structure
- `index.html` — interface
- `style.css` — mobile-first design
- `app.js` — frontend logic
- `functions/api/generate.js` — server-side Gemini call

## Next upgrades
Authentication, saved projects, PDF/Doc export, scene editor, image generation, voice generation, payments, usage limits.
