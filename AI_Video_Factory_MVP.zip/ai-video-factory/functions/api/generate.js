const MODEL = "gemini-3.7-flash";

const SYSTEM = `You are the AI engine inside AI Video Factory, a professional production assistant for faceless YouTube and short-form creators.
Return ONLY valid JSON with exactly these top-level keys:
script, scenes, image_prompts, video_prompts, voiceover, seo.

Requirements:
- script: polished narration suitable for the requested length and style.
- scenes: numbered scene breakdown with approximate timing, visual action, narration purpose, and transition.
- image_prompts: numbered cinematic prompts matching the scenes. Include subject, setting, era when relevant, composition, lighting, camera, atmosphere, and vertical 9:16 framing.
- video_prompts: numbered prompts for animating each corresponding scene, including camera movement and environmental motion.
- voiceover: clean narration only, without stage directions.
- seo: JSON object containing title_options (5), description, tags (15), and thumbnail_prompt.
Do not invent precise historical facts when the topic is uncertain; use cautious wording.`;

function jsonResponse(data, status=200){
  return new Response(JSON.stringify(data),{
    status,headers:{"content-type":"application/json;charset=UTF-8"}
  });
}

export async function onRequestPost(context){
  try{
    const body=await context.request.json();
    const topic=String(body.topic||"").trim();
    const length=String(body.length||"60 seconds");
    const style=String(body.style||"Documentary");
    if(!topic) return jsonResponse({error:"Topic is required."},400);

    const apiKey=context.env.GEMINI_API_KEY;
    if(!apiKey) return jsonResponse({error:"GEMINI_API_KEY is not configured yet. Add it as a secret in your deployment settings."},500);

    const prompt=`Create a complete video package.

TOPIC: ${topic}
VIDEO LENGTH: ${length}
STYLE: ${style}

Make the output coherent: every scene must match the narration, image prompts must match scenes, and video prompts must animate the same visuals.`;

    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${encodeURIComponent(apiKey)}`,{
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify({
        system_instruction:{parts:[{text:SYSTEM}]},
        contents:[{role:"user",parts:[{text:prompt}]}],
        generationConfig:{responseMimeType:"application/json"}
      })
    });

    const raw=await r.text();
    if(!r.ok) return jsonResponse({error:`Gemini API error: ${raw.slice(0,500)}`},502);

    const data=JSON.parse(raw);
    const text=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"";
    if(!text) return jsonResponse({error:"The AI returned an empty response."},502);

    let result;
    try{ result=JSON.parse(text); }
    catch{ return jsonResponse({error:"The AI response was not valid JSON. Try again."},502); }

    return jsonResponse(result);
  }catch(e){
    return jsonResponse({error:e.message||"Unexpected server error."},500);
  }
}
