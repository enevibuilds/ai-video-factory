const topic = document.querySelector("#topic");
const length = document.querySelector("#length");
const style = document.querySelector("#style");
const generate = document.querySelector("#generate");
const statusEl = document.querySelector("#status");
const results = document.querySelector("#results");
const tabs = document.querySelector("#tabs");
const outputTitle = document.querySelector("#outputTitle");
const outputText = document.querySelector("#outputText");
const copyCurrent = document.querySelector("#copyCurrent");
const copyAll = document.querySelector("#copyAll");

let packageData = {};
let currentKey = "";

function pretty(key){ return key.replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase()); }

function render(data){
  packageData = data;
  tabs.innerHTML = "";
  const preferred = ["script","scenes","image_prompts","video_prompts","voiceover","seo"];
  Object.keys(data).sort((a,b)=>preferred.indexOf(a)-preferred.indexOf(b)).forEach(key=>{
    const b=document.createElement("button");
    b.className="tab";
    b.textContent=pretty(key);
    b.onclick=()=>showSection(key);
    tabs.appendChild(b);
  });
  results.classList.remove("hidden");
  showSection(Object.keys(data)[0]);
  results.scrollIntoView({behavior:"smooth"});
}

function showSection(key){
  currentKey=key;
  outputTitle.textContent=pretty(key);
  const value=packageData[key];
  outputText.textContent=typeof value==="string" ? value : JSON.stringify(value,null,2);
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.textContent===pretty(key)));
}

async function callAI(){
  const t=topic.value.trim();
  if(!t){statusEl.textContent="Enter a video topic first.";return;}
  generate.disabled=true;
  statusEl.textContent="Creating your script, scenes, prompts and SEO package…";
  results.classList.add("hidden");
  try{
    const res=await fetch("/api/generate",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({topic:t,length:length.value,style:style.value})
    });
    const data=await res.json();
    if(!res.ok) throw new Error(data.error||"Generation failed.");
    render(data);
    statusEl.textContent="Done.";
  }catch(e){
    statusEl.textContent=e.message;
  }finally{generate.disabled=false;}
}

generate.onclick=callAI;
copyCurrent.onclick=()=>navigator.clipboard.writeText(outputText.textContent);
copyAll.onclick=()=>navigator.clipboard.writeText(Object.entries(packageData).map(([k,v])=>`### ${pretty(k)}\n${typeof v==="string"?v:JSON.stringify(v,null,2)}`).join("\n\n"));
